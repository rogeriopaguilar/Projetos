See http://jakarta.apache.org/commons/dbcp/ for additional and 
up-to-date information on Commons DBCP.
